require 'spec_helper'

describe Reminder do
  pending "add some examples to (or delete) #{__FILE__}"
end
