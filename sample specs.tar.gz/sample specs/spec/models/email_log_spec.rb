require 'spec_helper'

describe EmailLog do
  pending "add some examples to (or delete) #{__FILE__}"
end
