require 'spec_helper'

describe PeopleController do

end
