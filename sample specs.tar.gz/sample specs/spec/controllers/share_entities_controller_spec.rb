require 'spec_helper'

describe ShareEntitiesController do

end
