# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :checkin_item_tag do
    name "MyText"
    description "MyText"
  end
end
