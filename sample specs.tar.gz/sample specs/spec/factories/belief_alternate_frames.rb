# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :belief_alternate_frame do
    name "MyText"
    description "MyText"
  end
end
