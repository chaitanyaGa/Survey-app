# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :map_item_type do
    name "MyString"
    description "MyString"
  end
end
