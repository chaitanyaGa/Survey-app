# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :need_fulfilled_state do
    name "MyText"
    description "MyText"
  end
end
