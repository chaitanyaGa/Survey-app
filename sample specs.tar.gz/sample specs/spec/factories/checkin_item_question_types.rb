# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :checkin_item_question_type do
    name "MyString"
    description "MyText"
  end
end
