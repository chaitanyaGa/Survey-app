# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :life_without_believing do
    life_without_belief nil
    life_without_believable_id 1
    life_without_believable_type "MyString"
  end
end
