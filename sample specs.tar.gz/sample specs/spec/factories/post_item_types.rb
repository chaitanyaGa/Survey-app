# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :post_item_type do
    name "MyString"
  end
end
