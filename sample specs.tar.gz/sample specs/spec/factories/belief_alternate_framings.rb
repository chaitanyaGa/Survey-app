# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :belief_alternate_framing do
    belief_alternate_frame nil
    belief_alternate_frameable_id 1
    belief_alternate_frameable_type "MyString"
  end
end
