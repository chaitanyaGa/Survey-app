# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :thought_alternate_framing do
    thought_alternate_frame nil
    thought_alternate_frameable_id 1
    thought_alternate_frameable_type "MyString"
  end
end
