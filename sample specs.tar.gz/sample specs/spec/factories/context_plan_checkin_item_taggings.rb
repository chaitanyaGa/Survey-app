# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :context_plan_checkin_item_tagging do
    context_plan nil
    checkin_item_tag nil
  end
end
