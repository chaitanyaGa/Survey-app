# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :share_entity do
  end
end
