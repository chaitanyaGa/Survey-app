# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :life_without_belief do
    name "MyText"
    description "MyText"
  end
end
