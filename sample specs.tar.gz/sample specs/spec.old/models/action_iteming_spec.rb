require 'spec_helper'

describe ActionIteming do
  pending "add some examples to (or delete) #{__FILE__}"
end
