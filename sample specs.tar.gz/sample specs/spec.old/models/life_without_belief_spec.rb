require 'spec_helper'

describe LifeWithoutBelief do
  pending "add some examples to (or delete) #{__FILE__}"
end
