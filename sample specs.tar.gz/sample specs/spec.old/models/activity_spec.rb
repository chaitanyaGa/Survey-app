require 'spec_helper'

describe Activity do
  pending "add some examples to (or delete) #{__FILE__}"
end
