require 'spec_helper'

describe PostItem do
  pending "add some examples to (or delete) #{__FILE__}"
end
