require 'spec_helper'

describe ContextPlanTask do
  pending "add some examples to (or delete) #{__FILE__}"
end
