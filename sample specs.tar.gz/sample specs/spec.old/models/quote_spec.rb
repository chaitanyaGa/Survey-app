require 'spec_helper'

describe Quote do
  pending "add some examples to (or delete) #{__FILE__}"
end
