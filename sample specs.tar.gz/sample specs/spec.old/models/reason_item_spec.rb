require 'spec_helper'

describe ReasonItem do
  pending "add some examples to (or delete) #{__FILE__}"
end
