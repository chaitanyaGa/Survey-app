require 'spec_helper'

describe Reason do
  pending "add some examples to (or delete) #{__FILE__}"
end
