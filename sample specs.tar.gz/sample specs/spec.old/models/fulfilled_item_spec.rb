require 'spec_helper'

describe FulfilledItem do
  pending "add some examples to (or delete) #{__FILE__}"
end
