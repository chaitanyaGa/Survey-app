require 'spec_helper'

describe AlternateItem do
  pending "add some examples to (or delete) #{__FILE__}"
end
