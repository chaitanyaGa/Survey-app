require 'spec_helper'

describe NeedFulfilledStating do
  pending "add some examples to (or delete) #{__FILE__}"
end
