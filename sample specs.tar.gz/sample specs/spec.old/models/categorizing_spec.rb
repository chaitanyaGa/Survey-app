require 'spec_helper'

describe Categorizing do
  pending "add some examples to (or delete) #{__FILE__}"
end
