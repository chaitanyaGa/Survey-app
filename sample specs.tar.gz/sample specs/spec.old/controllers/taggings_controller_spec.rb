require 'spec_helper'

describe TaggingsController do

end
