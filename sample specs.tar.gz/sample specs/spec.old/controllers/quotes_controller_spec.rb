require 'spec_helper'

describe QuotesController do

end
